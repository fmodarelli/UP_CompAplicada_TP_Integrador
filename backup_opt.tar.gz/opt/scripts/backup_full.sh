FECHA=`date +%Y%m%d`
ORIGEN="$1"
DESTINO="$2"
NOMBRE="$3"

if [[ "$1" == "-help" || '$1' == "-h" || "$#" -ne 3 ]]; then
  echo "Uso: $0 [origen] [destino] [nombre_archivo]"
  echo "Ejemplo: $0 /var/log /backup_dir log_bkp"
  exit 1
fi

echo '\n'
echo "Inicio de comprobacion para saber si '$ORIGEN' esta disponible antes de ejecutar el backup..."

if [ ! -d "$ORIGEN" ]; then
  echo "Error: el directorio de origen '$ORIGEN' no está disponible."
  exit 2
else
  echo "Origen '$ORIGEN' está disponible."
fi

echo '\n'
echo 'Inicio de comprobacion para saber si '$DESTINO' esta disponible antes de ejecutar el backup...'
sleep 5

if ! mountpoint -q "$DESTINO"; then
  echo "Error: El '$DESTINO' no esta disponible"
  exit 4
else
  echo "Origen '$DESTINO' está disponible."
fi

echo '\n'
echo "Realizando copia de '$ORIGEN' en destino '$DESTINO' para posteriormente comprimir..."
cp -r $ORIGEN $DESTINO/$NOMBRE'_'$FECHA
echo "Realizada la copia de '$ORIGEN' en destino '$DESTINO'."
sleep 5

echo '\n'
echo "Comprimiendo carpeta anteriormente copiada en el destino '$DESTINO'..."
echo '\n'
tar -czvf $DESTINO/$NOMBRE'_'$FECHA.tag.gz $DESTINO/$NOMBRE'_'$FECHA
echo '\n'
echo "Realizada la compresion de la carpeta copiada en el destino '$DESTINO'."
sleep 5

echo '\n'
echo "Borrando carpeta copiada originalmente en '$DESTINO'..."
rm -r $DESTINO/$NOMBRE'_'$FECHA
echo "Se ha borrado la carpeta anteriormente copiada en '$DESTINO'."
sleep 5

echo '\n'
echo 'El script se ha ejecutado'
echo 'FIN'

